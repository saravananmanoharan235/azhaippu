<!-- <?php echo e(url('assets/img/sidebar-1.jpg')); ?> -->
        <div class="sidebar" data-active-color="purple" data-background-color="white" data-image="#">
    <!--
        Tip 1: You can change the color of active element of the sidebar using: data-active-color="purple | blue | green | orange | red | rose"
        Tip 2: you can also add an image using data-image tag
        Tip 3: you can change the color of the sidebar with data-background-color="white | black"
    -->

    <?php  
        //print_r(Request::segment('2')); exit;

        /*$segment = '';
        $route = Route::current();
        $actionname = $route->getActionName();

        $names = explode("@",$actionname);
        $segment = $names[1];*/
        $segment1 = Request::segment('1');
        $segment2 = Request::segment('2');
        $segment3 = Request::segment('3');
    ?>

    <div class="logo">
        <a href="<?php echo e(url('/home')); ?>" class="simple-text logo-mini">
            N 
        </a>

        <a href="<?php echo e(url('/home')); ?>" class="simple-text logo-normal">
            <?php echo e(config('app.name', 'Najez')); ?>

        </a>
    </div>

    <div class="sidebar-wrapper">
        
        <ul class="nav">

            <li class="<?php echo e(($segment1 =='home')?'active':''); ?>">
                <a href="<?php echo e(url('/home')); ?>">
                    <i class="material-icons">dashboard</i>
                    <p> Dashboard </p>
                </a>
            </li>
            
            <li class="<?php echo e(($segment2 =='riders')?'active':''); ?>">
                <a data-toggle="collapse" class="<?php echo e(($segment2 =='riders')?'':'collapsed'); ?>" href="#riderlist">
                    <i class="material-icons">person</i>
                    <p> Riders 
                       <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse <?php echo e(($segment2 =='riders')?'in':''); ?>" id="riderlist">
                    <ul class="nav">
                        <li class="<?php echo e(($segment2 =='riders' && $segment3 =='create')?'active':''); ?>">
                            <a href="<?php echo e(url('/admin/riders/create')); ?>" >
                                <span class="sidebar-mini"> A </span>
                                <span class="sidebar-normal"> Add </span>
                            </a>
                        </li>
                        <li class="<?php echo e(($segment2 =='riders' && $segment3 =='')?'active':''); ?>">
                            <a href="<?php echo e(url('/admin/riders')); ?>">
                                <span class="sidebar-mini"> L </span>
                                <span class="sidebar-normal"> List </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            
            <li class="<?php echo e(($segment2 =='drivers')?'active':''); ?>">
                <a data-toggle="collapse" class="<?php echo e(($segment2 =='drivers')?'':'collapsed'); ?>" href="#driverlist">
                    <i class="material-icons">airline_seat_recline_normal</i>
                    <p> Drivers 
                       <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse <?php echo e(($segment2 =='drivers')?'in':''); ?>" id="driverlist">
                    <ul class="nav">
                        <li class="<?php echo e(($segment2 =='drivers' && $segment3 =='create')?'active':''); ?>">
                            <a href="<?php echo e(url('/admin/drivers/create')); ?>" >
                                <span class="sidebar-mini"> A </span>
                                <span class="sidebar-normal"> Add </span>
                            </a>
                        </li>
                        <li class="<?php echo e(($segment2 =='drivers' && $segment3 =='')?'active':''); ?>">
                            <a href="<?php echo e(url('/admin/drivers')); ?>">
                                <span class="sidebar-mini"> L </span>
                                <span class="sidebar-normal"> List </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            
            <li class="<?php echo e(($segment2 =='reports')?'active':''); ?>">
                <a data-toggle="collapse" class="<?php echo e(($segment2 =='reports')?'':'collapsed'); ?>" href="#reportlist">
                    <i class="material-icons">report</i>
                    <p> Reports 
                       <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse <?php echo e(($segment2 =='reports')?'in':''); ?>" id="reportlist">
                    <ul class="nav">
                        <li class="<?php echo e(($segment2 =='reports' && $segment3 =='create')?'active':''); ?>">
                            <a href="<?php echo e(url('/admin/reports/create')); ?>" >
                                <span class="sidebar-mini"> A </span>
                                <span class="sidebar-normal"> Ongoing Ride </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            
            <li class="<?php echo e(($segment2 =='vehicles' || $segment2 =='vehicletypes')?'active':''); ?>">
                <a data-toggle="collapse" class="<?php echo e(($segment2 =='vehicles' || $segment2 =='vehicletypes')?'':'collapsed'); ?>" href="#vehicleslist">
                    <i class="material-icons">local_taxi</i>
                    <p> Vehicles 
                       <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse <?php echo e(($segment2 =='vehicles' || $segment2 =='vehicletypes')?'in':''); ?>" id="vehicleslist">
                    <ul class="nav">
                        <li class="<?php echo e(($segment2 =='vehicles' && $segment3 =='create')?'active':''); ?>">
                            <a href="<?php echo e(url('/admin/vehicles/create')); ?>" >
                                <span class="sidebar-mini"> A </span>
                                <span class="sidebar-normal"> Add </span>
                            </a>
                        </li>
                        <li class="<?php echo e(($segment2 =='vehicles' && $segment3 =='')?'active':''); ?>">
                            <a href="<?php echo e(url('/admin/vehicles')); ?>">
                                <span class="sidebar-mini"> L </span>
                                <span class="sidebar-normal"> List </span>
                            </a>
                        </li>
                        <li class="<?php echo e(($segment2 =='vehicletypes' && $segment3 =='')?'active':''); ?>">
                            <a href="<?php echo e(url('/admin/vehicletypes')); ?>" >
                                <span class="sidebar-mini"> VT </span>
                                <span class="sidebar-normal"> Vehicle Type </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="<?php echo e(($segment2 =='promotions')?'active':''); ?>">
                <a data-toggle="collapse" class="<?php echo e(($segment2 =='promotions')?'':'collapsed'); ?>" href="#promosionlist">
                    <i class="material-icons">class</i>
                    <p> Promotions 
                       <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse <?php echo e(($segment2 =='promotions')?'in':''); ?>" id="promosionlist">
                    <ul class="nav">
                        <li class="<?php echo e(($segment2 =='promotions' && $segment3 =='create')?'active':''); ?>">
                            <a href="<?php echo e(url('/admin/promotions/create')); ?>" >
                                <span class="sidebar-mini"> A </span>
                                <span class="sidebar-normal"> Add </span>
                            </a>
                        </li>
                        <li class="<?php echo e(($segment2 =='promotions' && $segment3 =='')?'active':''); ?>">
                            <a href="<?php echo e(url('/admin/promotions')); ?>">
                                <span class="sidebar-mini"> L </span>
                                <span class="sidebar-normal"> List </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="<?php echo e(($segment2 =='voucher')?'active':''); ?>">
                <a data-toggle="collapse" class="<?php echo e(($segment2 =='voucher')?'':'collapsed'); ?>" href="#voucherlist">
                    <i class="material-icons">card_giftcard</i>
                    <p> Voucher 
                       <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse <?php echo e(($segment2 =='voucher')?'in':''); ?>" id="voucherlist">
                    <ul class="nav">
                        <li class="<?php echo e(($segment2 =='voucher' && $segment3 =='create')?'active':''); ?>">
                            <a href="<?php echo e(url('/admin/voucher/create')); ?>" >
                                <span class="sidebar-mini"> A </span>
                                <span class="sidebar-normal"> Add </span>
                            </a>
                        </li>
                        <li class="<?php echo e(($segment2 =='voucher' && $segment3 =='')?'active':''); ?>">
                            <a href="<?php echo e(url('/admin/voucher')); ?>">
                                <span class="sidebar-mini"> L </span>
                                <span class="sidebar-normal"> List </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="<?php echo e(($segment2 =='feedbacks')?'active':''); ?>">
                <a data-toggle="collapse" class="<?php echo e(($segment2 =='feedbacks')?'':'collapsed'); ?>" href="#ratereviewlist">
                    <i class="material-icons">rate_review</i>
                    <p> FeedBack 
                       <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse <?php echo e(($segment2 =='feedbacks')?'in':''); ?>" id="ratereviewlist">
                    <ul class="nav">
                        <li class="<?php echo e(($segment2 =='feedbacks' && $segment3 =='create')?'active':''); ?>">
                            <a href="<?php echo e(url('/admin/feedbacks/create')); ?>" >
                                <span class="sidebar-mini"> A </span>
                                <span class="sidebar-normal"> Add </span>
                            </a>
                        </li>
                        <li class="<?php echo e(($segment2 =='feedbacks' && $segment3 =='')?'active':''); ?>">
                            <a href="<?php echo e(url('/admin/feedbacks')); ?>">
                                <span class="sidebar-mini"> L </span>
                                <span class="sidebar-normal"> List </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="<?php echo e(($segment2 =='pushnotifications')?'active':''); ?>">
                <a data-toggle="collapse" class="<?php echo e(($segment2 =='pushnotifications')?'':'collapsed'); ?>" href="#pushnotificationlist">
                    <i class="material-icons">notification_important</i>
                    <p> Push Notification 
                       <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse <?php echo e(($segment2 =='pushnotifications')?'in':''); ?>" id="pushnotificationlist">
                    <ul class="nav">
                        <li class="<?php echo e(($segment2 =='pushnotifications' && $segment3 =='create')?'active':''); ?>">
                            <a href="<?php echo e(url('/admin/pushnotifications/create')); ?>" >
                                <span class="sidebar-mini"> A </span>
                                <span class="sidebar-normal"> Add </span>
                            </a>
                        </li>
                        <li class="<?php echo e(($segment2 =='pushnotifications' && $segment3 =='')?'active':''); ?>">
                            <a href="<?php echo e(url('/admin/pushnotifications')); ?>">
                                <span class="sidebar-mini"> L </span>
                                <span class="sidebar-normal"> List </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>

        </ul>


    </div>
</div><?php /**PATH C:\xampp\htdocs\uberclone\resources\views/layouts/admin/sidebar.blade.php ENDPATH**/ ?>