<?php $__env->startSection('content'); ?>
<style type="text/css">
    hr {
    margin-top: 20px;
    margin-bottom: 20px;
    border: 0;
    border-top: 1px solid #eee;
}
</style>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-text" data-background-color="blue">
                        <h4 class="card-title">Add Vehicle Type</h4>
                    </div>
                    <div class="card-content">
                        <?php if(count($errors)): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div style="color: #ff0000;"><?php echo e($error); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

               			<form id="RegisterValidation" action="<?php echo e(url('/admin/vehicletypes')); ?>" method="post" autocomplete="nope" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                            <div class="row">
                                <div class="col-md-4 ">
                                    <div class="form-group label-floating">
                                        <label class="control-label" id="vehicle_type">Vehicle Type<small>*</small></label>
                                        <input type="text" class="form-control" id="vehicle_type" name="vehicle_type"  required="true" value="<?php echo e(old('vehicle_type')); ?>">
                                    </div>
                                </div>
                                <div class="col-md-4 ">
                                    <div class="form-group label-floating">
                                        <label class="control-label" id="available_seats">Available Seats<small>*</small></label>
                                        <input type="text" class="form-control" id="available_seats" name="available_seats"  required="true" value="<?php echo e(old('available_seats')); ?>">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <legend>Vehicle Type Image</legend>
                                    <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                        <!-- <div class="fileinput-new thumbnail">
                                            <img src="<?php echo e(url('assets/img/image_placeholder.jpg')); ?>" alt="...">
                                        </div> -->
                                        <div class="fileinput-preview fileinput-exists thumbnail"></div>
                                        <div>
                                            <span class="btn btn-rose btn-round btn-file">
                                                <span class="fileinput-new">Select file</span>
                                                <span class="fileinput-exists">Change</span>
                                                <input type="file" name="vehicle_image" />
                                            </span>
                                            <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card-footer text-center">
                                <!-- <button type="button" class="btn btn-rose btn-round btn-fill" onClick="SaveEmp()">Submit</button> -->
                            	<button type="submit" class="btn btn-rose btn-fill">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div> 
        </div>
    </div>
</div>

<script src="<?php echo e(url('assets/js/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('assets/js/jquery.validate.min.js')); ?>"></script>
<script type="text/javascript">



  /*$(function() {
		$("#RegisterValidation").validate({
			errorPlacement: function(error, element) {
				console.log('adsf');
				$(element).closest('div').addClass('has-error');
	        }
		});

  });*/
	function setFormValidation(id){
		$(id).validate({
			errorPlacement: function(error, element) {
				$(element).closest('div').addClass('has-error');
	        }
		});
	}

	$(document).ready(function(){
		setFormValidation('#RegisterValidation');
	});
	function SaveEmp(){
				console.log('aaaaa');
		setFormValidation('#RegisterValidation');		
	}
</script>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uberclone\resources\views/admin/vehicletypes/add.blade.php ENDPATH**/ ?>