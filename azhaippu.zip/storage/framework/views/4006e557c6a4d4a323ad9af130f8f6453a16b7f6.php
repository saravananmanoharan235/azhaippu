<?php $__env->startSection('content'); ?>
<style type="text/css">
    hr {
    margin-top: 20px;
    margin-bottom: 20px;
    border: 0;
    border-top: 1px solid #eee;
}
</style>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-text" data-background-color="blue">
                        <h4 class="card-title">Add Vehicle</h4>
                    </div>
                    <div class="card-content">
                        <?php if(count($errors)): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div style="color: #ff0000;"><?php echo e($error); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

               			<form id="RegisterValidation" action="<?php echo e(url('/admin/vehicles')); ?>" method="post" autocomplete="nope" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                            <div class="row">
                                <div class="col-md-4">
                                    <select class="selectpicker" data-style="btn btn-primary" title="Single Select" required="true" data-size="7" name="driverId" id="driverId">
                                        <option disabled selected>Choose Driver</option>
                                        <?php $__currentLoopData = $getDrivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php 
                                                if(old('driverId') == $driver->id){
                                                    $selected = 'selected';
                                                }else{
                                                    $selected = '';
                                                }
                                            ?>
                                            <option value="<?php echo e($driver->id); ?>" <?php echo e($selected); ?>><?php echo e($driver->fname); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-4 ">
                                    <div class="form-group label-floating">
                                        <label class="control-label" id="vehicle_sno">Serial Number of the vehicle <small>*</small></label>
                                        <input type="text" class="form-control" id="vehicle_sno" name="vehicle_sno"  required="true" value="<?php echo e(old('vehicle_sno')); ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group label-floating">
                                        <label class="control-label" id="vehicle_number">Vehicle Plate Number(abc1234) <small>*</small></label>
                                        <input type="text" class="form-control" id="vehicle_number" name="vehicle_number" required="true" value="<?php echo e(old('vehicle_number')); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <select class="selectpicker" data-style="btn btn-primary" title="Single Select" data-size="7" name="vehicle_type" id="vehicle_type">
                                        <option disabled selected>Type of the vehicle</option>
                                        <?php $__currentLoopData = $vehicle_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php 
                                                if(old('vehicle_type') == $vtype->id){
                                                    $selected = 'selected';
                                                }else{
                                                    $selected = '';
                                                }
                                            ?>
                                            <option value="<?php echo e($vtype->id); ?>" <?php echo e($selected); ?>><?php echo e($vtype->type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-4 ">
                                    <div class="form-group label-floating">
                                        <label class="control-label" id="vehicle_model">Car Model<small>*</small></label>
                                        <input type="text" class="form-control" id="vehicle_model" name="vehicle_model"  required="true" value="<?php echo e(old('vehicle_model')); ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <select class="selectpicker" data-style="btn btn-primary" title="Single Select" name="vehicle_year" id="vehicle_year">
                                        <option disabled selected>Year of manufacture</option>
                                        <?php for($starting_year = 2000; $starting_year <= date('Y'); $starting_year++) {
                                                if(old('vehicle_year') == $starting_year){
                                                    $selected = 'selected';
                                                }else{
                                                    $selected = '';
                                                }
                                            echo '<option value="'.$starting_year.'"  '.$selected.'>'.$starting_year.'</option>';
                                        }?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <select class="selectpicker" data-style="btn btn-primary" title="Single Select" name="vehicle_color" id="vehicle_color">
                                        <option disabled selected>Vehicle Color</option>
                                        <option value="Red" <?php if(old('vehicle_color') == 'Red') echo 'selected';?> >Red</option>
                                        <option value="Blue" <?php if(old('vehicle_color') == 'Blue') echo 'selected';?>>Blue</option>
                                        <option value="Green" <?php if(old('vehicle_color') == 'Green') echo 'selected';?>>Green</option>
                                        <option value="Yellow" <?php if(old('vehicle_color') == 'Yellow') echo 'selected';?>>Yellow</option>
                                        <option value="Black" <?php if(old('vehicle_color') == 'Black') echo 'selected';?>>Black</option>
                                        <option value="White" <?php if(old('vehicle_color') == 'White') echo 'selected';?>>White</option>
                                        <!-- fixed by nandini-->
                                        <option value="Silver" <?php if(old('vehicle_color') == 'White') echo 'selected';?>>Silver</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    &nbsp;
                                </div>

                                <div class="col-md-4">
                                    &nbsp;
                                </div>
                                <!-- <div class="col-md-4">
                                    <div class="form-group label-floating">
                                        <label class="control-label" id="iban">IBAN Number<small>*</small></label>
                                        <input type="text" class="form-control" name="iban" id="iban" required="true" value="<?php echo e(old('iban')); ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <select class="selectpicker" data-style="btn btn-primary" title="Single Select" name="iban_bank" id="iban_bank" >
                                        <option disabled selected>Bank</option>
                                        <option value="Alinma Bank">Alinma Bank</option>
                                        <option value="Al Rajhi Bank">Al Rajhi Bank</option>
                                        <option value="Arab National Bank">Arab National Bank</option>
                                        <option value="Asia Bank">Asia Bank</option>
                                        <option value="Banque Saudi Fransi">Banque Saudi Fransi</option>
                                        <option value="Bank Al-Bilad">Bank Al-Bilad</option>
                                        <option value="Bank AlJazira">Bank AlJazira</option>
                                        <option value="BNP Paribas">BNP Paribas</option>
                                        <option value="Deutsche Bank">Deutsche Bank</option>
                                        <option value="Emirates NBD">Emirates NBD</option>
                                        <option value="Gulf International Bank (GIB)">Gulf International Bank (GIB)</option>
                                        <option value="Industrial and Commercial Bank of China (ICBC)">Industrial and Commercial Bank of China (ICBC)</option>
                                        <option value="J.P. Morgan Chase N.A">J.P. Morgan Chase N.A</option>
                                        <option value="Muscat Bank">Muscat Bank</option>
                                        <option value="National Bank of Bahrain (NBB)">National Bank of Bahrain (NBB)</option>
                                        <option value="National Bank of Kuwait (NBK)">National Bank of Kuwait (NBK)</option>
                                        <option value="National Bank of Pakistan (NBP)">National Bank of Pakistan (NBP)</option>
                                        <option value="Qatar National Bank (QNB)">Qatar National Bank (QNB)</option>
                                        <option value="Riyad Bank">Riyad Bank</option>
                                        <option value="Saudi Investment Bank">Saudi Investment Bank</option>
                                        <option value="Samba Financial Group (Samba)">Samba Financial Group (Samba)</option>
                                        <option value="Saudi Hollandi Bank (Alawwal)">Saudi Hollandi Bank (Alawwal)</option>
                                        <option value="State Bank of India (SBI)">State Bank of India (SBI)</option>
                                        <option value="The National Commercial Bank">The National Commercial Bank</option>
                                        <option value="The Saudi British Bank">The Saudi British Bank</option>
                                        <option value="T.C.ZIRAAT BANKASI A.S.">T.C.ZIRAAT BANKASI A.S.</option>
                                    </select>
                                </div> -->
                            </div>
                    <hr/>
                            <div class="row">
                                <div class="col-md-4 col-sm-4">
                                    <legend>Driving License</legend>
                                    <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                        <!-- <div class="fileinput-new thumbnail">
                                            <img src="<?php echo e(url('assets/img/image_placeholder.jpg')); ?>" alt="...">
                                        </div> -->
                                        <div class="fileinput-preview fileinput-exists thumbnail"></div>
                                        <div>
                                            <span class="btn btn-rose btn-round btn-file">
                                                <span class="fileinput-new">Select file</span>
                                                <span class="fileinput-exists">Change</span>
                                                <input type="file" name="driver_license" />
                                            </span>
                                            <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 col-sm-4">
                                    <legend>Vehicle registration</legend>
                                    <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                        <!-- <div class="fileinput-new thumbnail">
                                            <img src="<?php echo e(url('assets/img/image_placeholder.jpg')); ?>" alt="...">
                                        </div> -->
                                        <div class="fileinput-preview fileinput-exists thumbnail"></div>
                                        <div>
                                            <span class="btn btn-rose btn-round btn-file">
                                                <span class="fileinput-new">Select file</span>
                                                <span class="fileinput-exists">Change</span>
                                                <input type="file" name="vehicle_registration" />
                                            </span>
                                            <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 col-sm-4">
                                    <legend>Insurance of vehicles</legend>
                                    <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                        <!-- <div class="fileinput-new thumbnail">
                                            <img src="<?php echo e(url('assets/img/image_placeholder.jpg')); ?>" alt="...">
                                        </div> -->
                                        <div class="fileinput-preview fileinput-exists thumbnail"></div>
                                        <div>
                                            <span class="btn btn-rose btn-round btn-file">
                                                <span class="fileinput-new">Select file</span>
                                                <span class="fileinput-exists">Change</span>
                                                <input type="file" name="vehicle_insurance" />
                                            </span>
                                            <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card-footer text-center">
                                <!-- <button type="button" class="btn btn-rose btn-round btn-fill" onClick="SaveEmp()">Submit</button> -->
                            	<button type="submit" class="btn btn-rose btn-fill">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div> 
        </div>
    </div>
</div>

<script src="<?php echo e(url('assets/js/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('assets/js/jquery.validate.min.js')); ?>"></script>
<script type="text/javascript">



  /*$(function() {
		$("#RegisterValidation").validate({
			errorPlacement: function(error, element) {
				console.log('adsf');
				$(element).closest('div').addClass('has-error');
	        }
		});

  });*/
	function setFormValidation(id){
		$(id).validate({
			errorPlacement: function(error, element) {
				$(element).closest('div').addClass('has-error');
	        }
		});
	}

	$(document).ready(function(){
		setFormValidation('#RegisterValidation');
	});
	function SaveEmp(){
				console.log('aaaaa');
		setFormValidation('#RegisterValidation');		
	}
</script>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uberclone\resources\views/admin/vehicles/add.blade.php ENDPATH**/ ?>