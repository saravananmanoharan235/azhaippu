<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Najez</title>
    <meta name="description" content="Najez">
    <meta name="keywords" content="Najez">
    <link rel="icon" href="<?php echo url('assets/home/'); ?>/img/favicon.ico" >
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:400,300|Raleway:300,400,900,700italic,700,300,600">
    <link rel="stylesheet" type="text/css" href="<?php echo url('assets/home/'); ?>/css/jquery.bxslider.css">
    <link rel="stylesheet" type="text/css" href="<?php echo url('assets/home/'); ?>/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo url('assets/home/'); ?>/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo url('assets/home/'); ?>/css/animate.css">
    <link rel="stylesheet" type="text/css" href="<?php echo url('assets/home/'); ?>/css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo url('assets/home/'); ?>/css/style-arabic.css">
    <link rel="stylesheet" href="<?php echo url('assets/home/'); ?>/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo url('assets/home/'); ?>/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?php echo url('assets/home'); ?>/css/bootstrap-datepicker.css">
     
    <!-- =======================================================
        Theme Name: Baker
        Theme URL: https://bootstrapmade.com/baker-free-onepage-bootstrap-theme/
        Author: BootstrapMade.com
        Author URL: https://bootstrapmade.com
    ======================================================= -->
  </head>
 
  <?php if(empty($this->session->userdata['site_lang']))
    { 
      $bodyID="english-lang";
    }
    elseif($this->session->userdata['site_lang'] =='english')
    {
      $bodyID="english-lang";
    }
    elseif($this->session->userdata['site_lang'] =='arabic')
    {
      $bodyID="arabic-lang";
    }
      $bodyID="english-lang";
   ?>
  <body  class="hold-transition skin-blue sidebar-mini" id="<?php echo $bodyID;?>">
  
    <div class="loader"></div>
    <div id="myDiv">
    <!--HEADER-->
    <div class="header">
      <div class="bg-color">
        <header id="main-header">

            <div class="row anti">
                <div class="col-lg-3 col-sm-3 col-xs-6 anti">
                    <a class="logos" href="<?php echo url('/'); ?>"><img src="<?php echo url('assets/home/'); ?>/img/logo.png" class="img-responsive" alt="logo" style="position: relative;z-index: 9999;" /><img src="<?php echo url('assets/home/'); ?>/img/logo-arabic.png" class="img-responsive arabic-only" alt="logo" style="position: relative;z-index: 9999;" /></a>
                </div>
                <div class="col-lg-7 col-sm-7">
                <nav class="navbar navbar-default navbar-fixed-top"> <!-- navbar-fixed-top -->
                <div class="navbar-header">
                
                
                
                
                
                
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
                  
                  
                  <div class="visible-xs btn-arab">
                        <div id="navbar">
                            <ul>
                                <li class="dropdown countryDropdown"> 
                                    
                                        
                                    
                                         
                                        
                                        
                                    <ul class="dropdown-menu" role="menu" aaa>
                                        <li><a id="navIta" href="<?php echo url('/'); ?>LanguageSwitcher/switchLang/arabic" class="language"><img id="" src="<?php echo url('/'); ?>assets/home/img/saudi-arabia.jpg" alt="..." class="imgNavIta img-thumbnail icon-small">  <span class="lanNavIta">Arabic</span></a></li>
                                        <li><a id="navEng" href="<?php echo url('/'); ?>LanguageSwitcher/switchLang/english" class="language"><img id="" src="<?php echo url('/'); ?>assets/home/img/Grossbritanien.jpg" alt="..." class="imgNavEng img-thumbnail icon-small">  <span class="lanNavEng">English</span></a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div> <!--/.navbar-collapse -->
                </div>
                  
                  
                  
                  
                  
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                 
                  <ul class="nav navbar-nav navbar-right">
                   <?php 
                   $active = 'home';

                   if ($active== 'home'){?>
                        <li class=""><a href="#"><?php echo  "HOME"; ?></a></li>
                        <li class=""><a href="#about-us"><?php echo  "ABOUT US"; ?></a></li>
                        <li class=""><a href="#services"><?php echo  "Services"; ?></a></li>
                        <li class=""><a class="main-active" href="#download-app"><?php echo "DOWNLOAD APP"; ?></a></li>
                    <?php }?> 
                  </ul>
                
                </div>
                
                </nav>
                </div>
                
            </div>
            
            
            
        
        </header>
        
        
        <div class="wrapper">
        
            <?php if ($active== 'home'){?>
            <div class="container">
                <div class="row">
                    <div class="banner-info text-center wow fadeIn delay-05s col-lg-12">
                        <h2 class="bnr-sub-title"><?php echo "Welcome to Najez"; ?></h2>
                        <p class="bnr-para"><?php echo "Anywhere Anytime Book Online"; ?></p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-xs-12 text-center"><a href="#download-app"><button class="button1 head-btn"><?php echo "JOIN AS A PARTNER"; ?></button></a></div>
                    <div class="col-lg-6 col-md-6 col-xs-12 text-center"><a href="#download-app"><button class="button2 head-btn"><?php echo "JOIN AS A USER"; ?></button></a></div>
                    <div class="overlay-detail">
                    </div>
                </div>            
            </div>
            <?php }else{?>          
            <div class="container">
                <div class="row">
                    <div class="banner-info text-center wow fadeIn delay-05s col-lg-12">
                        <h2 class="bnr-sub-title"><?php echo $page_title; ?> </h2>
                
                    </div>
                </div>
            </div>
            <?php }?>
            
        </div>
      </div>
 </div>











 <section id="about-us" class="section-padding wow fadeInUp delay-05s">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-sm-4 col-xs-12 text-center"> <img src="<?php echo url('assets/home/'); ?>/img/mobile1.png" class="img-responsive" style="margin:0 auto;"> </div>
      <div class="col-lg-6 col-md-6 col-sm-8 col-xs-12 content">
        <p class="space-150"></p>
        <h1><?php echo "About Us"; ?></h1>
        <h5><?php echo "A 100% Saudi owned brand coming across stunningly. Najez is an amazing venture committed towards providing the best services across the Kingdom of Saudi Arabia. Our vision is to become a business leader dedicated towards delivering excellent quality services with evolving growth and success."; ?></h5>
        <div class="more_about" style="display:none;padding:0 !important;margin:0 !important;">
          <h5><?php echo "A pioneering company exceptionally creating and implementing reliable and high-quality services to meet the customers and partners needs successfully. Najez is determined to never let their partners & customers down with their uniqueness."; ?></h5>
          <h5><?php echo "In all aspects, Najez is there for you 24x7. Najez is all set to deliver unbeatable innovative quality services with everlasting commitment driven through our professional class management practices"; ?></h5>
        </div>
        <p>
          <button class="butn about_btn1"><?php echo "Learn More"; ?></button>
          <button class="butn  about_btn2" style="display:none;"><?php echo "Hide"; ?></button>
        </p>
      </div>
    </div>
  </div>
</section>
<!---->

</section>
<!----> 
<!----> 

<!--third-->
<section id="feature" class="section-padding wow fadeIn delay-05s">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center">
        <h2 class="service-title pad-bt15"><?php echo "BENEFITS"; ?></h2>
        <p class="sub-title pad-bt35"><i><?php echo "We give you better benefits"; ?></i></p>
      </div>
      <div class="col-sm-4 col-xs-12 box-one">
        <div class="wrap-item text-center">
          <div class="item-img"> <img src="<?php echo url('assets/home/'); ?>/img/icon1.png">
            <p><?php echo "Better customer satisfaction"; ?></p>
          </div>
        </div>
      </div>
      <div class="col-sm-4 col-xs-12 box-two">
        <div class="wrap-item text-center">
          <div class="item-img"> <img src="<?php echo url('assets/home/'); ?>/img/quality-partner.png">
            <p><?php echo "Easy to use and understand"; ?></p>
          </div>
        </div>
      </div>
      <div class="col-sm-4 col-xs-12 box-three">
        <div class="wrap-item text-center">
          <div class="item-img"> <img src="<?php echo url('assets/home/'); ?>/img/incentive.png">
            <p><?php echo "Incentives at its best"; ?></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!----> 

<!---->
<section id="services" class="section-padding wow fadeInUp delay-05s">
  <div class="container">
  <div class="row">
    <div class="col-md-12 text-center">
      <h2 class="service-title" style="color:#fff;"><?php echo "SERVICES"; ?></h2>
      <p class="sub-title task "><i><?php echo "a lot of amazing & cool features"; ?></i></p>
    </div>
  </div>
  <div class="row images">
    <div class="col-lg-4 content1">
      <div class="row row-margin">
        <div class="col-lg-9 col-md-9 col-sm-9 col-xs-8 anti">
          <h3><?php echo "SAVE YOUR ARRIVAL AND DEPARTURE LOCATION"; ?></h3>
          <P><?php echo "Save your arrival and departure points in the sophisticated application to ease the booking process."; ?></P>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-4 heart text-center"> <img src="<?php echo url('assets/home/'); ?>/img/heart.png"> </div>
      </div>
      <div class="row row-margin">
        <div class="col-lg-9 col-md-9 col-sm-9 col-xs-8 anti">
          <h3><?php echo "RIGHT VEHICLE JUST ONE CLICK AWAY"; ?></h3>
          <P><?php echo "You can choose any type of vehicle which fulfils your needs - delivery/ medium/ family/ luxury."; ?></P>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-4 text-center heart anti-right"> <img src="<?php echo url('assets/home/'); ?>/img/heart.png"> </div>
      </div>
      <div class="row row-margin">
        <div class="col-lg-9 col-md-9 col-sm-9 col-xs-8">
          <h3><?php echo "ANALYSING YOUR CAPTAIN" ?></h3>
          <P><?php echo "You can have a look at your captain’s picture and rating based on customer opinions and evaluate him."; ?></P>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-4 text-center heart"> <img src="<?php echo url('assets/home/'); ?>/img/heart.png"> </div>
      </div>
    </div>
    <div class="col-lg-4 contentcenter"> </div>
    <div class="col-lg-4 content2">
      <div class="row row-margin">
        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-4 text-center heart anti-left"> <img src="<?php echo url('assets/home/'); ?>/img/heart.png"> </div>
        <div class="col-lg-9 col-md-9 col-sm-9 col-xs-8 anti">
          <h3><?php echo 'DISCOUNTS &amp; STUNNING SERVICE'; ?></h3>
          <P><?php echo 'We always strive to be competitive in the market and give you the best discounts and offers.'; ?></P>
        </div>
      </div>
      <div class="row row-margin">
        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-4 text-center heart anti-left"> <img src="<?php echo url('assets/home/'); ?>/img/heart.png"> </div>
        <div class="col-lg-9 col-md-9 col-sm-9 col-xs-8 anti">
          <h3><?php echo 'TRACKING THE ROUTES'; ?></h3>
          <P><?php echo 'You can have a look at your captain’s path and track him for your convenience until you reach your destination.'; ?></P>
        </div>
      </div>
      <div class="row row-margin">
        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-4 text-center heart anti-left"> <img src="<?php echo url('assets/home/'); ?>/img/heart.png"> </div>
        <div class="col-lg-9 col-md-9 col-sm-9 col-xs-8 anti">
          <h3><?php echo 'RATE &amp; FEEDBACK'; ?></h3>
          <P><?php echo 'Did you liked the ride? Rate it!<br/>Rating your captain is valuable, it gives us the assurance that the captain is fulfilling all his duties in the right manner.'; ?></P>
        </div>
      </div>
    </div>
  </div>
</section>
<!----> 
<!----> 
<!---->
<section id="portfolio1" class="section-padding wow fadeInUp delay-05s">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12 text-center">
        <h2 class="service-title"><?php echo 'TERMS OF USE'; ?></h2>
        <p class="sub-title pad-bt15" style="display:none;"><i style="color:#7f7c7c;">Get the app flow here</i></p>
      </div>
    </div>
  </div>
  <!--.container-->
  <div class="container-fluid">
    <div class="row">
      <div class="loop owl-carousel owl-theme"> 
        <!-- Start img 1 -->
        <?php if (empty($this->session->userdata['site_lang'])) { ?>
        <div class="item"><img src="<?php echo url('assets/home/'); ?>/img/slide8.jpg" alt="Owl Image1" class="img-responsive"></div>
        <?php } elseif ($this->session->userdata['site_lang'] == 'english') { ?>
        <div class="item"><img src="<?php echo url('assets/home/'); ?>/img/slide8.jpg" alt="Owl Image1" class="img-responsive"></div>
        <?php } elseif ($this->session->userdata['site_lang'] == 'arabic') { ?>
        <div class="item"><img src="<?php echo url('assets/home/'); ?>/img/slide8-arabic.jpg" alt="Owl Image1" class="img-responsive"></div>
        <?php } ?>
        <!-- End img 1 --> 
        
        <!-- Start img 2 -->
        <?php if (empty($this->session->userdata['site_lang'])) { ?>
        <div class="item"><img src="<?php echo url('assets/home/'); ?>/img/slide1.jpg" class="img-responsive"></div>
        <?php } elseif ($this->session->userdata['site_lang'] == 'english') { ?>
        <div class="item"><img src="<?php echo url('assets/home/'); ?>/img/slide1.jpg" class="img-responsive"></div>
        <?php } elseif ($this->session->userdata['site_lang'] == 'arabic') { ?>
        <div class="item"><img src="<?php echo url('assets/home/'); ?>/img/slide1-arabic.jpg" class="img-responsive"></div>
        <?php } ?>
        <!-- End img 2 -->
        
        <div class="item"><img src="<?php echo url('assets/home/'); ?>/img/slide2.jpg" class="img-responsive"></div>
        
        <!-- Start img 3 -->
        <?php if (empty($this->session->userdata['site_lang'])) { ?>
        <div class="item"><img src="<?php echo url('assets/home/'); ?>/img/slide3.jpg" class="img-responsive"></div>
        <?php } elseif ($this->session->userdata['site_lang'] == 'english') { ?>
        <div class="item"><img src="<?php echo url('assets/home/'); ?>/img/slide3.jpg" class="img-responsive"></div>
        <?php } elseif ($this->session->userdata['site_lang'] == 'arabic') { ?>
        <div class="item"><img src="<?php echo url('assets/home/'); ?>/img/slide3-arabic.jpg" class="img-responsive"></div>
        <?php } ?>
        <!-- End img 3 --> 
        
        <!-- Start img 4 -->
        <?php if (empty($this->session->userdata['site_lang'])) { ?>
        <div class="item"><img src="<?php echo url('assets/home/'); ?>/img/slide5.jpg" class="img-responsive"></div>
        <?php } elseif ($this->session->userdata['site_lang'] == 'english') { ?>
        <div class="item"><img src="<?php echo url('assets/home/'); ?>/img/slide5.jpg" class="img-responsive"></div>
        <?php } elseif ($this->session->userdata['site_lang'] == 'arabic') { ?>
        <div class="item"><img src="<?php echo url('assets/home/'); ?>/img/slide5-arabic.jpg" class="img-responsive"></div>
        <?php } ?>
        <!-- End img 4 --> 
        
      </div>
    </div>
  </div>
</section>

<!----> 
<!---->
<section id="download-app" class=" wow fadeInUp delay-05s">
  <div class="bg-testicolor section-padding">
    <div class="container centered">
      <div class="row">
        <div class="testimonial-item col-lg-12">
          <h1><?php echo 'DOWNLOAD THE APP'; ?></h1>
          <p><i><?php echo 'Register to get an early access'; ?></i></p>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 text-center white"> 
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 anti tg-one">
              <p class="btn1 pull-right"><?php echo 'Download Partner App'; ?></p>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 anti tg-two">
              <p class="btn2 pull-left"><?php echo 'Download User App'; ?></p>
            </div>
          </div>
        </div>
      </div>
      <div class="row"> 
        <!-- first form start -->
        <div class="contact-form" id="form1">
          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 btns">
            <h3><i><?php echo 'Download the app and start earning with Najez'; ?></i></h3>
            <?php if (empty($this->session->userdata['site_lang']) || $this->session->userdata['site_lang'] == 'english') { ?>
            <a href="#join-us">
            <button class=""><img src="<?php echo url('assets/home/'); ?>/img/and-roid.png"> <?php echo 'android'; ?></button>
            </a>
            <?php } elseif ($this->session->userdata['site_lang'] == 'arabic') { ?>
            <a href="#join-us">
            <button class=""><?php echo 'android'; ?><img src="<?php echo url('assets/home/'); ?>/img/and-roid.png"> </button>
            </a>
            <?php } ?>
            <?php if (empty($this->session->userdata['site_lang']) || $this->session->userdata['site_lang'] == 'english') { ?>
            <a href="#join-us">
            <button class=""><img src="<?php echo url('assets/home/'); ?>/img/ios.png"> <?php echo 'ios'; ?></button>
            </a>
            <?php } elseif ($this->session->userdata['site_lang'] == 'arabic') { ?>
            <a href="#join-us">
            <button class=""> <?php echo 'ios'; ?><img src="<?php echo url('assets/home/'); ?>/img/ios.png"></button>
            </a>
            <?php } ?>
          </div>
          <!-- <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 text-center downloadapp-img"><img class="app-download img-responsive" src="http://najez-online.com/assets/home//img/download-app-driver.png" /></div> -->
          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 text-center downloadapp-img"><img class="app-download img-responsive" src="<?php echo url('assets/home/'); ?>/img/download-app-driver.png" /></div>
        </div>
        <!-- first form end --> 
        <!-- second form start -->
        <div class="contact-form1" id="form2" style="display:none;">
          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 btns">
            <h3><i><?php echo 'Download the App and start riding with Najez'; ?></i></h3>
            <?php if (empty($this->session->userdata['site_lang']) || $this->session->userdata['site_lang'] == 'english') { ?>
            <a href="#join-us">
            <button class=""><img src="<?php echo url('assets/home/'); ?>/img/and-roid.png"> <?php echo 'android'; ?></button>
            </a>
            <?php } elseif ($this->session->userdata['site_lang'] == 'arabic') { ?>
            <a href="#join-us">
            <button class=""><?php echo 'android'; ?><img src="<?php echo url('assets/home/'); ?>/img/and-roid.png"> </button>
            </a>
            <?php } ?>
            <?php if (empty($this->session->userdata['site_lang']) || $this->session->userdata['site_lang'] == 'english') { ?>
            <a href="#join-us">
            <button class=""><img src="<?php echo url('assets/home/'); ?>/img/ios.png"> <?php echo 'ios'; ?></button>
            </a>
            <?php } elseif ($this->session->userdata['site_lang'] == 'arabic') { ?>
            <a href="#join-us">
            <button class=""> <?php echo 'ios'; ?><img src="<?php echo url('assets/home/'); ?>/img/ios.png"></button>
            </a>
            <?php } ?>
          </div>
          <!-- <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 text-center downloadapp-img"><img class="app-download img-responsive" src="http://najez-online.com/assets/home//img/download-app.png" /></div> -->
          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 text-center downloadapp-img"><img class="app-download img-responsive" src="<?php echo url('assets/home/'); ?>/img/download-app.png" /></div>
        </div>
        <!-- sencond form end --> 
        
      </div>
      
    </div>
  </div>
</section>
<!---->
<section id="blog" class="section-padding wow fadeInUp delay-05s" style="display:none;">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center">
        <h2 class="service-title pad-bt15"><?php echo 'blog'; ?>BLOG</h2>
        <p class="sub-title pad-bt15"><i style="color:#7f7c7c;"><?php echo 'have_look_our_blog'; ?>Have look our blog</i></p>
      </div>
      <div class="col-md-4 col-sm-6 col-xs-12">
        <div class="blog-sec" style="background-color:#fafafa;">
          <div class="blog-img"> <a href=""> <img src="<?php echo url('assets/home/'); ?>/img/car.jpg" class="img-responsive"> </a> </div>
          <div class="blog-info">
            <h2><?php echo 'quis_autem_bel_eum_iure_qui_in'; ?>QUIS AUTEM VEL EUM IURE QUI IN</h2>
            <p><?php echo 'we_cannot_expect_people_to_have_respect_for'; ?>We cannot expect people to have respect for laws and orders until we teach respect to those we have entrusted to enforce those laws all the time. we always want to help people cordially.</p>
            <hr/>
            <a href="" class="read-more"><?php echo 'dec112016_1'; ?>DEC 11, 2016</a> <a href="" class="read-more pull-right"> <?php echo 'read_more'; ?>READ MORE</a> </div>
        </div>
      </div>
      <div class="col-md-4 col-sm-6 col-xs-12">
        <div class="blog-sec" style="background-color:#fafafa;">
          <div class="blog-img"> <a href=""> <img src="<?php echo url('assets/home/'); ?>/img/hand.jpg" class="img-responsive"> </a> </div>
          <div class="blog-info">
            <h2><?php echo 'quis_autem_vel_eum_iure_qui_in'; ?>QUIS AUTEM VEL EUM IURE QUI IN</h2>
            <p><?php echo 'we_cannot_expect_people_to_have_respect'; ?>We cannot expect people to have respect for laws and orders until we teach respect to those we have entrusted to enforce those laws all the time. we always want to help people cordially.</p>
            <hr/>
            <a href="" class="read-more"><?php echo 'dec112016_2'; ?>DEC 11, 2016</a> <a href="" class="read-more pull-right"><?php echo 'read_more'; ?>READ MORE</a> </div>
        </div>
      </div>
      <div class="col-md-4 col-sm-6 col-xs-12">
        <div class="blog-sec" style="background-color:#fafafa;">
          <div class="blog-img"> <a href=""> <img src="<?php echo url('assets/home/'); ?>/img/car1.jpg" class="img-responsive"> </a> </div>
          <div class="blog-info">
            <h2><?php echo 'quis_autem_vel_eum_iure_qui_in'; ?>QUIS AUTEM VEL EUM IURE QUI IN</h2>
            <p><?php echo 'we_cannot_expect_people_to_have_respect'; ?>We cannot expect people to have respect for laws and orders until we teach respect to those we have entrusted to enforce those laws all the time. we always want to help people cordially.</p>
            <hr/>
            <a href="" class="read-more"><?php echo 'dec112016_3'; ?>DEC 11, 2016</a> <a href="" class="read-more pull-right"><?php echo 'read_more'; ?>READ MORE</a> </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!---->
<section id="join-us" class="section-padding wow fadeInUp delay-05s">
  <div class="container"> 
 
  </div>
</section>
<!----> 



<!-- Footer start -->
<section id="feature1" class="section-padding wow fadeIn delay-05s">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h2 class="service-title pad-bt15"><?php echo 'GET IN TOUCH'; ?></h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="wrap-item text-center">
                    <div class="item-img">
                        <img src="<?php echo url('assets/home/'); ?>/img/phone.png">
                    </div>

<?php if (empty($this->session->userdata['site_lang'])) { ?> 
                      <p dir=ltr lang=ar><?php echo 'phone'; ?> :<span dir=ltr lang= en-us><?php echo '+966540988577'; ?></span></p>
<?php } elseif ($this->session->userdata['site_lang'] == 'english') { ?> 
                      <p dir=ltr lang=ar><?php echo 'phone'; ?> :<span dir=ltr lang= en-us><?php echo '+966540988577'; ?></span></p>   
<?php } elseif ($this->session->userdata['site_lang'] == 'arabic') { ?> 
                      <p dir=rtl lang=ar><?php echo 'phone'; ?> :<span dir=ltr lang= en-us><?php echo '+966540988577'; ?></span></p>   
<?php } ?>



                </div>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="wrap-item text-center">
                    <div class="item-img">
                        <img src="<?php echo url('assets/home/'); ?>/img/mssg.png">
                    </div>
                    <p dir=rtl lang=ar><?php echo 'email'; ?> : <a href="mailto:info@najez-online.com" style="color:#333;"><?php echo 'infonajwz-onlinecom'; ?>info@najez-online.com</a></p>
                </div>

            </div>
            <div class="col-md-4 col-sm-4 col-xs-12" style="display:none;">
                <div class="wrap-item text-center">
                    <div class="item-img">
                        <img src="<?php echo url('assets/home/'); ?>/img/web.png">
                    </div>
                    <p><?php echo 'web:wwwyoursitecom'; ?></p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="wrap-item text-center">
                    <div class="item-img">


<!--<a href="#"><img src="<?php echo url('assets/home/'); ?>/img/fb.jpg" style="margin-top: 50px;"></a>-->
<!--<a href="#"><img src="<?php echo url('assets/home/'); ?>/img/google.jpg" style="margin-top: 50px;"></a>-->


<?php if (empty($this->session->userdata['site_lang'])) { ?> 
                          <a href="https://twitter.com/najez_ksa" target="_blank"><img src="<?php echo url('assets/home/'); ?>/img/twitter.png" style="margin-top: 50px;"></a>
<?php } elseif ($this->session->userdata['site_lang'] == 'english') { ?> 
                          <a href="https://twitter.com/najez_ksa" target="_blank"><img src="<?php echo url('assets/home/'); ?>/img/twitter.png" style="margin-top: 50px;"></a>  
<?php } elseif ($this->session->userdata['site_lang'] == 'arabic') { ?> 
                          <a href="https://twitter.com/najez_ksa" target="_blank"><img src="<?php echo url('assets/home/'); ?>/img/twitter-arabic.png" style="margin-top: 50px;"></a>   
<?php } ?>


<?php if (empty($this->session->userdata['site_lang'])) { ?> 
                          <a href="https://instagram.com/najez_ksa" target="_blank"><img src="<?php echo url('assets/home/'); ?>/img/instagram.png" style="margin-top: 50px;"></a>
<?php } elseif ($this->session->userdata['site_lang'] == 'english') { ?> 
                          <a href="https://instagram.com/najez_ksa" target="_blank"><img src="<?php echo url('assets/home/'); ?>/img/instagram.png" style="margin-top: 50px;"></a>  
<?php } elseif ($this->session->userdata['site_lang'] == 'arabic') { ?> 
                          <a href="https://instagram.com/najez_ksa" target="_blank"><img src="<?php echo url('assets/home/'); ?>/img/insta2-arabic.png" style="margin-top: 50px;"></a>  
<?php } ?>





                    </div>
                </div>
            </div>
        </div>
    </div>
</section>   


<!---->
<footer id="footer">
    <div class="container">
        <div class="row text-center" style="padding-top:40px;">
            <p><?php echo '&copy; 2019 Najez. All right reserved'; ?> | <a href="<?php echo url('page/privacy-policy'); ?>"><?php echo 'Privacy Policy'; ?></a></p>

        </div>
    </div>
</footer>
<!---->
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="<?php echo url('assets/home'); ?>/js/jquery.js"></script>
<script src="<?php echo url('assets/home'); ?>/js/jquery.min.js"></script>
<script src="<?php echo url('assets/home'); ?>/js/jquery.easing.min.js"></script>
<script src="<?php echo url('assets/home'); ?>/js/bootstrap.min.js"></script>
<script src="<?php echo url('assets/home'); ?>/js/wow.js"></script>
<script src="<?php echo url('assets/home'); ?>/js/jquery.bxslider.min.js"></script>
<script src="<?php echo url('assets/home'); ?>/js/custom.js"></script>
<!--<script src="contactform/contactform.js"></script>-->
<script src="<?php echo url('assets/home'); ?>/js/owl.carousel.min.js"></script>
<script src="<?php echo url('assets/home'); ?>/js/bootstrap-datepicker.js"></script>

<script src="<?php echo url('assets/home'); ?>/js/form_validation.js"></script>
<script type="text/javascript" src="https://cdn.ywxi.net/js/1.js" async></script>

<!-- btn  -->
<style>
    #radioBtn a {
        padding: 6px 34px;
        font-size: 15px;
    }
    #radioBtn .notActive{
        color: #ff9e15;
        background-color: #fff;
    }
    #radioBtn .active{
        color: #fff;
        background-color: #ff9e15;
        border-color: #ff9e15;
    }
    .more_about{padding:0 !important;padding:0 !important;}
</style>
<script>
                                  var html = $('.partner_driver').html();
                                  $('#form1').html(html);
                                  $('#form1').find('#driver_type').prop('value', 'Driver');
                                  jQuery('.form-group input, .form-group select').bind("focusout", function () {
                                      jQuery(this).removeClass('error');
                                      jQuery(this).next('.validation').hide();
                                      jQuery(this).next('.validation').next('.validation').hide();
                                      jQuery(this).next('.validation').next('.validation').next('.validation').hide();
                                  });
                                  var d = new Date();
                                  $('#form1').find('#date').datepicker({
                                      //format: 'yyyy-mm-dd',
                                      format: 'dd/mm/yyyy',
                                      startDate: '01/01/1940',
                                      autoclose: true
                                  });
                                  $('#form1').find('#date_driverlicenseinput, #date_vehicleinsurinput, #date_tafweethimginput, #date_vehiclereginput').datepicker({
                                      //format: 'yyyy-mm-dd',
                                      format: 'dd/mm/yyyy',
                                      startDate: '0d',
                                      autoclose: true
                                  });
                                  
                                  $('.photo').bind('change', function (e) {

                                      var photo = e.target.files[0].name;
                                      var ext = photo.split('.').pop().toLowerCase();
                                      if ($.inArray(ext, ['gif', 'png', 'jpg', 'jpeg']) == -1) {
                                          alert('Invalid File. Use only gif, png, jpg, jpeg');
                                          $(this).val('');
                                          var id = $(this).attr('id');
                                          $('#form1').find('#' + id + '_date').hide();
                                      } else {
                                          var id = $(this).attr('id');
                                          $('#form1').find('#hidez').hide();
                                          $('#form1').find('#' + id + '_date').show();
                                      }

                                  });
                                  $('#radioBtn a').on('click', function () {
                                      $('.formshow').show();
                                      var sel = $(this).data('title');
                                      var tog = $(this).data('toggle');

                                      if (sel == 'Delivery Man') {
                                          var html = $('.partner_delivery').html();
                                          $('#form1').html(html);
                                          $('#form1').find('#' + tog).prop('value', sel);

                                      } else {
                                          var html = $('.partner_driver').html();
                                          $('#form1').html(html);
                                          $('#form1').find('#' + tog).prop('value', sel);
                                      }
                                      $('a[data-toggle="' + tog + '"]').not('[data-title="' + sel + '"]').removeClass('active').addClass('notActive');
                                      $('a[data-toggle="' + tog + '"][data-title="' + sel + '"]').removeClass('notActive').addClass('active');
                                      jQuery('.form-group input, .form-group select').bind("focusout", function () {
                                          jQuery(this).removeClass('error');
                                          jQuery(this).next('.validation').hide();
                                          jQuery(this).next('.validation').next('.validation').hide();
                                          jQuery(this).next('.validation').next('.validation').next('.validation').hide();
                                      });
                                      
                                      var d = new Date();
                                      $('#form1').find('#date').datepicker({
                                          //format: 'yyyy-mm-dd',
                                          format: 'dd/mm/yyyy',
                                          startDate: '01/01/1940',
                                          autoclose: true
                                      });
                                      $('#form1').find('#date_driverlicenseinput, #date_vehicleinsurinput, #date_tafweethimginput, #date_vehiclereginput').datepicker({
                                          //format: 'yyyy-mm-dd',
                                          format: 'dd/mm/yyyy',
                                          startDate: '0d',
                                          autoclose: true
                                      });

                                      $('.photo').bind('change', function (e) {

                                          var photo = e.target.files[0].name;
                                          var ext = photo.split('.').pop().toLowerCase();
                                          if ($.inArray(ext, ['gif', 'png', 'jpg', 'jpeg']) == -1) {
                                              alert('Invalid File. Use only gif, png, jpg, jpeg');
                                              $(this).val('');
                                              var id = $(this).attr('id');
                                              $('#form1').find('#' + id + '_date').hide();
                                          } else {
                                              var id = $(this).attr('id');
                                              $('#form1').find('#hidez').hide();
                                              $('#form1').find('#' + id + '_date').show();
                                          }

                                      });
                                  });

//function formsubmitfunc(test){ console.log(test);}


</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\uberclone\resources\views/welcome.blade.php ENDPATH**/ ?>