<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-text" data-background-color="blue">
                        <h4 class="card-title">Add Rider</h4>
                    </div>
                    <div class="card-content">
                        <?php if(count($errors)): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div style="color: #ff0000;"><?php echo e($error); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

               			<form id="RegisterValidation" action="<?php echo e(url('/admin/riders')); ?>" method="post" autocomplete="nope">
                        <?php echo csrf_field(); ?>
                        	<div class="row">
                                <div class="col-md-6 ">
									<div class="form-group label-floating">
                                        <label class="control-label" id="label_blue">Name <small>*</small></label>
                                        <input type="text" class="form-control" id="fname" name="fname"  required="true" value="<?php echo e(old('fname')); ?>">
                                    </div>
								</div>
                                <div class="col-md-6">
                                    <div class="form-group label-floating">
                                        <label class="control-label" id="label_blue">Email <small>*</small></label>
                                        <input type="text" class="form-control" id="email" name="email" required="true" email="true" value="<?php echo e(old('email')); ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                	<div class="form-group label-floating">
                                        <label class="control-label" id="label_blue">Password <small>*</small></label>
                                        <input type="password" class="form-control" id="password" name="password" required="true"  autocomplete="new-password" minLength="6" maxlength="10" value="<?php echo e(old('password')); ?>">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group label-floating">
                                        <label class="control-label" id="label_blue">Mobile <small>*</small></label>
                                        <input type="text" class="form-control" id="mobileno" name="mobileno" required="true" number="true" minLength="10" maxlength="10" value="<?php echo e(old('mobileno')); ?>">
                                    </div>
                                </div>
							</div>
                            <div class="card-footer text-center">
                                <!-- <button type="button" class="btn btn-rose btn-round btn-fill" onClick="SaveEmp()">Submit</button> -->
                            	<button type="submit" class="btn btn-rose btn-fill">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div> 
        </div>
    </div>
</div>

<script src="<?php echo e(url('assets/js/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('assets/js/jquery.validate.min.js')); ?>"></script>
<script type="text/javascript">



  /*$(function() {
		$("#RegisterValidation").validate({
			errorPlacement: function(error, element) {
				console.log('adsf');
				$(element).closest('div').addClass('has-error');
	        }
		});

  });*/
	function setFormValidation(id){
		$(id).validate({
			errorPlacement: function(error, element) {
				$(element).closest('div').addClass('has-error');
	        }
		});
	}

	$(document).ready(function(){
		setFormValidation('#RegisterValidation');
	});
	function SaveEmp(){
				console.log('aaaaa');
		setFormValidation('#RegisterValidation');		
	}
</script>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\azhaippu\resources\views/admin/events/add.blade.php ENDPATH**/ ?>