<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(url('assets/img/apple-icon.png')); ?>" />
    <link rel="icon" type="image/png" href="<?php echo e(url('assets/img/favicon.png')); ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <title><?php echo e(config('app.name', 'Work Smart')); ?></title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">  


    <!--  Social tags      -->
    <meta name="keywords" content="">

    <meta name="description" content="">

    <!-- Bootstrap core CSS     -->
    <link href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />

    <!--  Material Dashboard CSS    -->
    <link href="<?php echo e(url('assets/css/material-dashboard98f3.css?v=1.3.0')); ?>" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project   -->
    <link href="<?php echo e(url('assets/css/demo.css')); ?>" rel="stylesheet" />
    
    <!--     Fonts and icons     -->
    <link href="<?php echo e(url('assets/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons" />
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">





    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });
    </script>
    <script type="text/javascript">
        var base_url = 'http://localhost/azhaippu/public';
        //var base_url = 'http://aegham.com/azhaippu/public';
    </script>

</head>


<body >

    <div class="wrapper">
    <?php echo $__env->make('layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php /**PATH C:\xampp\htdocs\azhaippu\resources\views/layouts/admin.blade.php ENDPATH**/ ?>